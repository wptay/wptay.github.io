Code is provided as is. Please cite

W. Luo, W. P. Tay, and M. Leng, �How to identify an infection source with limited observations,� IEEE J. Sel. Topics Signal Process., vol. 8, no. 4, pp. 586 � 597, Aug. 2014